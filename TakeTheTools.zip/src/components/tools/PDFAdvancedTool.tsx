"use client";

import { useState } from "react";
import { FileText, Hash, Edit, Download, Loader2, Check } from "lucide-react";
import { PDFDocument, rgb, StandardFonts } from "pdf-lib";
import * as pdfjsLib from "pdfjs-dist";
import FileUpload from "./FileUpload";

pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;

interface PDFAdvancedToolProps {
    mode: "numbering" | "metadata" | "image-to-pdf" | "pdf-to-image";
}

export default function PDFAdvancedTool({ mode }: PDFAdvancedToolProps) {
    const [file, setFile] = useState<File | null>(null);
    const [isProcessing, setIsProcessing] = useState(false);
    const [metadata, setMetadata] = useState({
        title: "",
        author: "",
        subject: "",
        creator: "TakeTheTools"
    });

    const processPDF = async () => {
        if (!file) return;
        setIsProcessing(true);
        try {
            const arrayBuffer = await file.arrayBuffer();
            const pdfDoc = await PDFDocument.load(arrayBuffer);

            if (mode === "numbering") {
                const pages = pdfDoc.getPages();
                const font = await pdfDoc.embedFont(StandardFonts.Helvetica);

                pages.forEach((page, index) => {
                    const { width, height } = page.getSize();
                    page.drawText(`Page ${index + 1} of ${pages.length}`, {
                        x: width / 2 - 50,
                        y: 20,
                        size: 10,
                        font,
                        color: rgb(0, 0, 0),
                    });
                });
            } else if (mode === "metadata") {
                pdfDoc.setTitle(metadata.title);
                pdfDoc.setAuthor(metadata.author);
                pdfDoc.setSubject(metadata.subject);
                pdfDoc.setCreator(metadata.creator);
            } else if (mode === "image-to-pdf") {
                const imgBytes = await file.arrayBuffer();
                let image;
                if (file.type === "image/jpeg" || file.type === "image/jpg") {
                    image = await pdfDoc.embedJpg(imgBytes);
                } else if (file.type === "image/png") {
                    image = await pdfDoc.embedPng(imgBytes);
                } else {
                    throw new Error("Only JPG/PNG supported for Image to PDF");
                }
                const page = pdfDoc.addPage([image.width, image.height]);
                page.drawImage(image, { x: 0, y: 0, width: image.width, height: image.height });
            } else if (mode === "pdf-to-image") {
                const arrayBuffer = await file.arrayBuffer();
                const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
                const page = await pdf.getPage(1); // Extract first page
                const viewport = page.getViewport({ scale: 2.0 });
                
                const canvas = document.createElement("canvas");
                const context = canvas.getContext("2d");
                canvas.height = viewport.height;
                canvas.width = viewport.width;

                await page.render({ canvasContext: context!, viewport }).promise;
                const imgData = canvas.toDataURL("image/png");
                
                const link = document.createElement("a");
                link.href = imgData;
                link.download = `page_1_${file.name.split(".")[0]}.png`;
                link.click();
                return; // Exit early as we handled the download
            }

            const pdfBytes = await pdfDoc.save();
            const type = "application/pdf";
            const extension = "pdf";
            const blob = new Blob([new Uint8Array(pdfBytes)], { type });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = `processed_${file.name.split(".")[0]}.${extension}`;
            link.click();
        } catch (e) {
            console.error(e);
            alert("Error processing PDF");
        } finally {
            setIsProcessing(false);
        }
    };

    return (
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-8">
            <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center text-primary-600">
                    {mode === "numbering" ? <Hash className="w-6 h-6" /> : <Edit className="w-6 h-6" />}
                </div>
                <div>
                    <h3 className="text-xl font-bold text-slate-900 capitalize">PDF {mode.replace(/-/g, " ")}</h3>
                    <p className="text-sm text-slate-500">
                        {mode === "numbering" && "Add page numbers to your document"}
                        {mode === "metadata" && "Edit PDF title, author, and subject"}
                        {mode === "image-to-pdf" && "Convert your images into a PDF document"}
                        {mode === "pdf-to-image" && "Extract pages from PDF as high-quality images"}
                    </p>
                </div>
            </div>

            <FileUpload
                onFilesSelected={(files) => setFile(files[0])}
                accept={mode === "image-to-pdf" ? { "image/*": [".jpg", ".jpeg", ".png"] } : { "application/pdf": [".pdf"] }}
                multiple={false}
            />

            {file && (
                <div className="space-y-6">
                    {mode === "metadata" && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest pl-2">Title</label>
                                <input
                                    type="text"
                                    value={metadata.title}
                                    onChange={(e) => setMetadata({ ...metadata, title: e.target.value })}
                                    className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl"
                                    placeholder="Document Title"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest pl-2">Author</label>
                                <input
                                    type="text"
                                    value={metadata.author}
                                    onChange={(e) => setMetadata({ ...metadata, author: e.target.value })}
                                    className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl"
                                    placeholder="Author Name"
                                />
                            </div>
                        </div>
                    )}

                    <button
                        onClick={processPDF}
                        disabled={isProcessing}
                        className="w-full py-4 bg-primary-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2"
                    >
                        {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Download className="w-5 h-5" />}
                        {isProcessing ? "Processing..." : `Download Processed PDF`}
                    </button>
                </div>
            )}
        </div>
    );
}
